MovieHub Entertainment Center
==============================

This folder is the whole app.

To make an Android app (APK) from it, the easiest free route is:
1. Upload this whole folder (or the zip) to https://app.netlify.com/drop
   Netlify gives you a web address, for example https://your-name.netlify.app
2. Open https://www.pwabuilder.com, paste that address, and choose
   "Package for stores" then "Android". Download the .apk it creates.
3. On the tablet, open the .apk and allow installs from your browser or
   file app when Android asks.

Notes
- Your library starts empty in the installed app. Use Settings > Export backup
  in the web version first, then Settings > Import backup in the app.
- The AI assistant and automatic descriptions only work when the page is
  opened from claude.ai while signed in. Everything else works offline.

Google Drive (optional)
- Open Settings > Google Drive for the one-time setup steps.
- Google sign-in only works from the address you add to your Google Cloud
  OAuth client (for example your Netlify address), not from a preview.
