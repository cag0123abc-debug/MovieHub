# MovieHub Entertainment Center

Static web app. No build step.

- `index.html` is the whole app.
- `version.json` holds the current version. Keep it in step with `APP_VERSION` in `index.html`.
- `netlify.toml` tells Netlify not to cache the app page, so updates show up on reload.

Deploying: connect this repository to Netlify (Add new site → Import from Git). Netlify publishes every commit to the main branch.
